import os
import requests
from tqdm import tqdm
from app.config import settings
from app.vectorstores.faiss_store import FaissVectorStore
from app.vectorstores.pinecone_store import PineconeVectorStore

def get_vector_store():
    if settings.vector_store == "pinecone":
        return PineconeVectorStore()
    return FaissVectorStore()

def confluence_get(url):
    return requests.get(
        url,
        auth=(settings.confluence_email, settings.confluence_api_token),
        headers={"Accept": "application/json"}
    )

def run():
    if not settings.confluence_base_url:
        raise RuntimeError("CONFLUENCE_BASE_URL missing")

    vector = get_vector_store()

    base = settings.confluence_base_url.rstrip("/")
    space = settings.confluence_space_key

    url = f"{base}/rest/api/content?spaceKey={space}&limit=50&expand=body.storage,version"
    resp = confluence_get(url).json()

    items = []
    for page in tqdm(resp.get("results", [])):
        page_id = page["id"]
        title = page["title"]
        body = page.get("body", {}).get("storage", {}).get("value", "")
        page_url = f"{base}/spaces/{space}/pages/{page_id}"

        content = f"TITLE: {title}\n\nBODY:\n{body}"

        items.append({
            "id": f"confluence_{page_id}",
            "content": content,
            "type": "text",
            "pageUrl": page_url,
            "allowed_groups": ["all"]
        })

    if items:
        vector.upsert(items)

    print(f"Ingested {len(items)} confluence pages.")

if __name__ == "__main__":
    run()
