import os
import json
import numpy as np
import faiss
from typing import List, Dict, Any
from app.vectorstores.base import VectorStore
from app.utils.embedding import embed_text

INDEX_PATH = "indexes/faiss.index"
META_PATH = "indexes/faiss_meta.json"

class FaissVectorStore(VectorStore):
    def __init__(self):
        self.dim = 1536
        self.index = None
        self.meta = []
        self._load()

    def _load(self):
        if os.path.exists(INDEX_PATH) and os.path.exists(META_PATH):
            self.index = faiss.read_index(INDEX_PATH)
            with open(META_PATH, "r", encoding="utf-8") as f:
                self.meta = json.load(f)
        else:
            self.index = faiss.IndexFlatIP(self.dim)
            self.meta = []

    def _save(self):
        os.makedirs("indexes", exist_ok=True)
        faiss.write_index(self.index, INDEX_PATH)
        with open(META_PATH, "w", encoding="utf-8") as f:
            json.dump(self.meta, f, indent=2)

    def upsert(self, items: List[Dict[str, Any]]):
        vectors = []
        for it in items:
            emb = embed_text(it["content"])
            vectors.append(emb)
            self.meta.append(it)

        vectors = np.array(vectors).astype("float32")
        faiss.normalize_L2(vectors)
        self.index.add(vectors)
        self._save()

    def query(self, text: str, top_k: int = 5, filters: Dict[str, Any] | None = None) -> List[Dict[str, Any]]:
        q = np.array([embed_text(text)]).astype("float32")
        faiss.normalize_L2(q)

        scores, idx = self.index.search(q, top_k)
        results = []
        for i in idx[0]:
            if i < 0 or i >= len(self.meta):
                continue
            doc = self.meta[i]

            # Basic filtering (group-based)
            if filters and "allowed_groups" in filters:
                allowed = set(doc.get("allowed_groups", ["all"]))
                user_groups = set(filters["allowed_groups"])
                if allowed.isdisjoint(user_groups) and "all" not in allowed:
                    continue

            results.append(doc)
        return results
