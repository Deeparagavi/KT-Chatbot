from fastapi import FastAPI, UploadFile, File, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from app.auth import authenticate_user, create_access_token, get_current_user
from app.config import settings
from app.utils.storage import save_upload
from app.utils.vision import ocr_image
from app.vectorstores.faiss_store import FaissVectorStore
from app.vectorstores.pinecone_store import PineconeVectorStore
from app.llm import answer_with_context

app = FastAPI(title="Org KT Chatbot Backend", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_vector_store(vector_store: str):
    if vector_store == "pinecone":
        return PineconeVectorStore()
    return FaissVectorStore()

VECTOR = None

@app.on_event("startup")
def startup():
    global VECTOR
    VECTOR = get_vector_store(settings.vector_store)

@app.post("/auth/login")
def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        return {"error": "Invalid username/password"}

    token = create_access_token({"sub": user["username"], "groups": user["groups"]})
    return {"access_token": token, "token_type": "bearer"}

@app.post("/chat")
def chat(payload: dict, user=Depends(get_current_user)):
    question = payload.get("question", "")
    if not question:
        return {"error": "question is required"}

    retrieved = VECTOR.query(
        question,
        top_k=6,
        filters={"allowed_groups": user.get("groups", ["all"])}
    )

    result = answer_with_context(question, retrieved)
    return result

@app.post("/upload-image")
def upload_image(file: UploadFile = File(...), user=Depends(get_current_user)):
    path = save_upload(file, "uploads")
    text = ocr_image(path)

    # Basic response: OCR + suggestion
    return {
        "filename": file.filename,
        "stored_path": path,
        "ocr_text": text[:4000]
    }
