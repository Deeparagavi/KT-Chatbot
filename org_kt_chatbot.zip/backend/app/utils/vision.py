from PIL import Image
import pytesseract
from openai import OpenAI
from app.config import settings

_client = None

def _get_client():
    global _client
    if _client is None:
        _client = OpenAI(api_key=settings.openai_api_key)
    return _client

def ocr_image(image_path: str) -> str:
    img = Image.open(image_path)
    return pytesseract.image_to_string(img)

def caption_image(image_path: str) -> str:
    client = _get_client()
    with open(image_path, "rb") as f:
        img_bytes = f.read()

    # Uses OpenAI multimodal
    resp = client.chat.completions.create(
        model=settings.openai_model,
        messages=[
            {"role": "system", "content": "You describe images for retrieval. Be factual and concise."},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Describe this image with key details for search indexing."},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,"}}
                ]
            }
        ]
    )
    # NOTE: placeholder because base64 inline is non-trivial in offline mode.
    # For production, encode image to base64 and send.
    return "Image captioning placeholder (enable base64 image to OpenAI)."
