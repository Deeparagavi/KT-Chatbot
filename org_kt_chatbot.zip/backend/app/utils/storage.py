import os
import shutil
from fastapi import UploadFile

BASE_STORAGE = "storage"

def save_upload(file: UploadFile, folder: str) -> str:
    os.makedirs(os.path.join(BASE_STORAGE, folder), exist_ok=True)
    dest_path = os.path.join(BASE_STORAGE, folder, file.filename)

    with open(dest_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    return dest_path
