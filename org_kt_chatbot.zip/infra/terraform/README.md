# AWS Terraform Deployment (Scaffold)

This folder provides a scaffold to deploy the system on AWS.

Recommended architecture:
- ECS Fargate for backend
- ECS Fargate for frontend
- ALB for routing
- S3 for file storage
- CloudWatch for logs
- Pinecone for vector DB (recommended managed mode)

FAISS mode can run inside backend container, but is not horizontally scalable.

## TODO (for production)
- Add VPC + subnets
- Add ECS cluster + task definitions
- Add ALB + target groups
- Add IAM roles for S3 access
- Add Secrets Manager for OPENAI_API_KEY

This repo is intentionally lightweight so you can extend it.

---
