import { useState } from "react";
import axios from "axios";

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";

export default function Home() {
  const [token, setToken] = useState("");
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("admin123");

  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState([]);
  const [uploadFile, setUploadFile] = useState(null);

  async function login() {
    const form = new FormData();
    form.append("username", username);
    form.append("password", password);

    const res = await axios.post(`${BACKEND}/auth/login`, form);
    if (res.data.access_token) {
      setToken(res.data.access_token);
      alert("Login success");
    } else {
      alert("Login failed");
    }
  }

  async function ask() {
    if (!token) return alert("Login first");
    if (!question) return;

    setMessages((m) => [...m, { role: "user", content: question }]);

    const res = await axios.post(
      `${BACKEND}/chat`,
      { question },
      { headers: { Authorization: `Bearer ${token}` } }
    );

    setMessages((m) => [...m, { role: "assistant", content: res.data.answer, images: res.data.images || [], citations: res.data.citations || [] }]);
    setQuestion("");
  }

  async function uploadImage() {
    if (!token) return alert("Login first");
    if (!uploadFile) return alert("Choose an image first");

    const form = new FormData();
    form.append("file", uploadFile);

    const res = await axios.post(`${BACKEND}/upload-image`, form, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "multipart/form-data",
      },
    });

    setMessages((m) => [
      ...m,
      { role: "assistant", content: "OCR Extracted:\n" + res.data.ocr_text },
    ]);
  }

  return (
    <div style={{ padding: 20, fontFamily: "Arial" }}>
      <h2>Org KT Chatbot (Confluence + Multimodal RAG)</h2>

      <div style={{ marginTop: 20, padding: 10, border: "1px solid #ddd" }}>
        <h3>Login</h3>
        <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="username" />
        <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="password" type="password" />
        <button onClick={login}>Login</button>
      </div>

      <div style={{ marginTop: 20, padding: 10, border: "1px solid #ddd" }}>
        <h3>Upload Image (OCR)</h3>
        <input type="file" accept="image/*" onChange={(e) => setUploadFile(e.target.files[0])} />
        <button onClick={uploadImage}>Upload</button>
      </div>

      <div style={{ marginTop: 20 }}>
        <h3>Chat</h3>
        <div style={{ border: "1px solid #ddd", padding: 10, height: 400, overflowY: "scroll" }}>
          {messages.map((m, idx) => (
            <div key={idx} style={{ marginBottom: 15 }}>
              <b>{m.role}:</b>
              <pre style={{ whiteSpace: "pre-wrap" }}>{m.content}</pre>

              {m.images && m.images.length > 0 && (
                <div>
                  <b>Images:</b>
                  {m.images.map((img, i) => (
                    <div key={i}>
                      <img src={img} style={{ maxWidth: "400px", border: "1px solid #ccc" }} />
                    </div>
                  ))}
                </div>
              )}

              {m.citations && m.citations.length > 0 && (
                <div>
                  <b>Sources:</b>
                  <ul>
                    {m.citations.map((c, i) => (
                      <li key={i}>
                        <a href={c} target="_blank">{c}</a>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>

        <div style={{ marginTop: 10 }}>
          <textarea
            rows={3}
            style={{ width: "100%" }}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask something..."
          />
          <button onClick={ask}>Send</button>
        </div>
      </div>
    </div>
  );
}
