# Org KT Chatbot (Confluence + Multimodal RAG) — Localhost + AWS-ready

This project is a **full-stack organization chatbot** for KT / onboarding newbies.

It supports:
- ✅ Confluence ingestion (pages + attachments)
- ✅ RAG over text + images
- ✅ User login authentication (local JWT now; AWS Cognito ready)
- ✅ Image upload (user can ask questions about screenshots/diagrams)
- ✅ Confluence images are indexed (OCR + captioning)
- ✅ Bot can return images as output (stored attachment URLs)
- ✅ Runs locally with Docker Compose
- ✅ AWS deployment ready (ECS/Fargate + S3 + optional Pinecone)
- ✅ Vector DB selectable via CLI param:
  - `--vector-store faiss`
  - `--vector-store pinecone`

---

## Architecture (High level)

Frontend (Next.js)  --->  Backend (FastAPI)
                              |
                              |-> Confluence Loader (REST API)
                              |-> OCR + Vision captioning
                              |-> Embeddings
                              |-> Vector Store (FAISS local OR Pinecone)
                              |-> LLM (OpenAI / Bedrock-ready)

Storage:
- Local: `backend/storage/`
- AWS: S3 bucket (Terraform templates included)

---

# Quickstart (Localhost)

## 1) Requirements
- Docker + Docker Compose
- Optional (if not using docker): Python 3.11+, Node 18+

## 2) Configure environment
Copy env template:

```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env.local
```

Edit `backend/.env`:
- `OPENAI_API_KEY=...` (required for best multimodal answers)
- Confluence creds if using Confluence ingestion

## 3) Run everything
```bash
docker compose up --build
```

Then open:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000/docs

Default local user:
- username: `admin`
- password: `admin123`

---

# Using the Chatbot

## Ask normal questions
Example:
> What is our deployment process?

## Upload image + ask questions
Upload a screenshot (error log / diagram) and ask:
> What does this mean? What should I do next?

## Ask to retrieve an architecture diagram
Example:
> Show me the architecture diagram for streaming pipeline.

If the image exists in Confluence attachments, the bot will return it.

---

# Ingest Confluence Content

## Configure Confluence
Set these in `backend/.env`:

```env
CONFLUENCE_BASE_URL=https://yourcompany.atlassian.net/wiki
CONFLUENCE_EMAIL=your@email.com
CONFLUENCE_API_TOKEN=your_api_token
CONFLUENCE_SPACE_KEY=KT
```

## Run ingestion (inside backend container)
```bash
docker exec -it org-kt-backend python -m app.ingest.confluence_ingest
```

It will:
- pull Confluence pages
- download attachments (including images)
- OCR + caption images
- chunk + embed
- index into FAISS (default)

---

# Vector Store Selection (FAISS vs Pinecone)

By default, backend uses FAISS.

To use Pinecone instead:

```bash
docker exec -it org-kt-backend python -m app.cli.run_server --vector-store pinecone
```

Or set in `.env`:

```env
VECTOR_STORE=pinecone
```

---

# AWS Deployment

This repo includes:
- Docker images (frontend/backend)
- Terraform templates (ECS + ALB + S3)
- Pinecone mode supported (recommended for managed vector DB)

## Typical AWS Architecture
- ECS Fargate (backend + frontend)
- S3 for attachments/images
- CloudWatch logs
- (Optional) Pinecone for embeddings
- (Optional) Cognito for auth

See: `infra/terraform/README.md`

---

# Security Notes (Important)
- RBAC is scaffolded (group-based doc filtering).
- For real production, integrate SSO (Cognito/Azure AD) and enforce:
  - per-user group claims
  - retrieval-time filtering

---

# Repo Structure

```
org_kt_chatbot/
  backend/        FastAPI RAG backend
  frontend/       Next.js chat UI
  infra/          Terraform AWS templates
  docker-compose.yml
```

---

# Next Steps
If you want, I can extend this project with:
- Jira integration (create ticket from chat)
- Slack/Teams bot integration
- Fine-grained Confluence permission syncing
- Observability dashboards

---


## New in v2
- True OpenAI Vision captioning implemented (base64 upload)
- Confluence image attachments are downloaded + OCR + captioned + indexed
- Backend serves Confluence images via `/static/confluence/...`

- PDF attachment ingestion added (downloads PDF + extracts text via PyMuPDF + indexes into vector store)
