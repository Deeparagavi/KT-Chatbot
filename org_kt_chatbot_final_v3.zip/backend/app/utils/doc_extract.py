import os
import fitz  # PyMuPDF

def extract_pdf_text(pdf_path: str, max_pages: int = 30) -> str:
    """
    Extracts text from a PDF using PyMuPDF.
    For KT docs, this is usually sufficient (PPT exported as PDF works great too).
    """
    doc = fitz.open(pdf_path)
    out = []
    pages = min(len(doc), max_pages)

    for i in range(pages):
        page = doc[i]
        out.append(page.get_text("text"))

    return "\n".join(out).strip()

def is_pdf(filename: str) -> bool:
    return filename.lower().endswith(".pdf")
