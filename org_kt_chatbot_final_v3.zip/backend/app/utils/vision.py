from PIL import Image
import pytesseract
import base64
from openai import OpenAI
from app.config import settings

_client = None

def _get_client():
    global _client
    if _client is None:
        _client = OpenAI(api_key=settings.openai_api_key)
    return _client

def ocr_image(image_path: str) -> str:
    img = Image.open(image_path)
    return pytesseract.image_to_string(img)

def _image_to_base64_data_url(image_path: str) -> str:
    with open(image_path, "rb") as f:
        data = f.read()
    b64 = base64.b64encode(data).decode("utf-8")

    # Basic mime inference
    lower = image_path.lower()
    if lower.endswith(".jpg") or lower.endswith(".jpeg"):
        mime = "image/jpeg"
    elif lower.endswith(".webp"):
        mime = "image/webp"
    else:
        mime = "image/png"

    return f"data:{mime};base64,{b64}"

def caption_image(image_path: str) -> str:
    """
    Uses OpenAI multimodal model (GPT-4o / GPT-4.1) to produce a semantic caption.
    This is essential for indexing diagrams, UI screenshots, charts, etc.
    """
    if not settings.openai_api_key:
        return ""

    client = _get_client()
    data_url = _image_to_base64_data_url(image_path)

    resp = client.chat.completions.create(
        model=settings.openai_model,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a technical assistant generating image captions for enterprise search indexing. "
                    "Describe the image precisely. If it is a diagram, explain components and arrows. "
                    "If it is an error screenshot, extract the error meaning. "
                    "Output should be concise but information-rich."
                )
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Create a searchable technical caption for this image."},
                    {"type": "image_url", "image_url": {"url": data_url}}
                ]
            }
        ],
        temperature=0.2
    )

    return resp.choices[0].message.content.strip()
