import argparse
import os
import uvicorn

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--vector-store", choices=["faiss", "pinecone"], default="faiss")
    args = parser.parse_args()

    os.environ["VECTOR_STORE"] = args.vector_store

    uvicorn.run("app.api:app", host="0.0.0.0", port=8000, reload=False)

if __name__ == "__main__":
    main()
