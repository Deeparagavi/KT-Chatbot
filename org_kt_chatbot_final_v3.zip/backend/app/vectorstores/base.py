from abc import ABC, abstractmethod
from typing import List, Dict, Any

class VectorStore(ABC):
    @abstractmethod
    def upsert(self, items: List[Dict[str, Any]]):
        ...

    @abstractmethod
    def query(self, text: str, top_k: int = 5, filters: Dict[str, Any] | None = None) -> List[Dict[str, Any]]:
        ...
