from typing import List, Dict, Any
from pinecone import Pinecone
from app.vectorstores.base import VectorStore
from app.config import settings
from app.utils.embedding import embed_text

class PineconeVectorStore(VectorStore):
    def __init__(self):
        if not settings.pinecone_api_key:
            raise RuntimeError("PINECONE_API_KEY is missing")

        self.pc = Pinecone(api_key=settings.pinecone_api_key)
        self.index = self.pc.Index(settings.pinecone_index)

    def upsert(self, items: List[Dict[str, Any]]):
        vectors = []
        for i, it in enumerate(items):
            vec = embed_text(it["content"])
            vectors.append((it["id"], vec, it))
        self.index.upsert(vectors=vectors)

    def query(self, text: str, top_k: int = 5, filters: Dict[str, Any] | None = None) -> List[Dict[str, Any]]:
        vec = embed_text(text)
        res = self.index.query(vector=vec, top_k=top_k, include_metadata=True)
        out = []
        for m in res.matches:
            meta = m.metadata or {}
            out.append(meta)
        return out
