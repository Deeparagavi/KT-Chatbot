from pydantic import BaseModel
from dotenv import load_dotenv
import os

load_dotenv()

class Settings(BaseModel):
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    jwt_secret: str = os.getenv("JWT_SECRET", "change_me")
    jwt_exp_minutes: int = int(os.getenv("JWT_EXP_MINUTES", "1440"))

    vector_store: str = os.getenv("VECTOR_STORE", "faiss")

    confluence_base_url: str = os.getenv("CONFLUENCE_BASE_URL", "")
    confluence_email: str = os.getenv("CONFLUENCE_EMAIL", "")
    confluence_api_token: str = os.getenv("CONFLUENCE_API_TOKEN", "")
    confluence_space_key: str = os.getenv("CONFLUENCE_SPACE_KEY", "")

    pinecone_api_key: str = os.getenv("PINECONE_API_KEY", "")
    pinecone_index: str = os.getenv("PINECONE_INDEX", "org-kt-chatbot")
    pinecone_environment: str = os.getenv("PINECONE_ENVIRONMENT", "us-east-1")

    storage_mode: str = os.getenv("STORAGE_MODE", "local")
    s3_bucket_name: str = os.getenv("S3_BUCKET_NAME", "")
    aws_region: str = os.getenv("AWS_REGION", "us-east-1")

settings = Settings()
