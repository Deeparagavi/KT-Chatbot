import os
import re
import requests
from tqdm import tqdm
from urllib.parse import urljoin
from app.config import settings
from app.utils.vision import ocr_image, caption_image
from app.utils.doc_extract import extract_pdf_text
from app.vectorstores.faiss_store import FaissVectorStore
from app.vectorstores.pinecone_store import PineconeVectorStore

CONFLUENCE_STORAGE_DIR = "storage/confluence"

def get_vector_store():
    if settings.vector_store == "pinecone":
        return PineconeVectorStore()
    return FaissVectorStore()

def confluence_get(url):
    return requests.get(
        url,
        auth=(settings.confluence_email, settings.confluence_api_token),
        headers={"Accept": "application/json"}
    )

def confluence_download(url, out_path):
    r = requests.get(
        url,
        auth=(settings.confluence_email, settings.confluence_api_token),
        stream=True
    )
    r.raise_for_status()
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "wb") as f:
        for chunk in r.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)

def _safe_filename(name: str) -> str:
    name = name.strip().replace(" ", "_")
    name = re.sub(r"[^a-zA-Z0-9._-]", "_", name)
    return name[:200]

def ingest_page_attachments(base: str, page_id: str, page_url: str):
    """
    Downloads Confluence attachments (images) and indexes them as multimodal docs.
    """
    attach_url = f"{base}/rest/api/content/{page_id}/child/attachment?limit=200"
    resp = confluence_get(attach_url)
    if resp.status_code != 200:
        return []

    data = resp.json()
    results = []

    for att in data.get("results", []):
        title = att.get("title", "attachment")
        media_type = att.get("metadata", {}).get("mediaType", "")

        # Support images + PDFs
        is_image = media_type.startswith("image/")
        is_pdf = title.lower().endswith(".pdf") or media_type == "application/pdf"
        if not (is_image or is_pdf):
            continue

        download_rel = att.get("_links", {}).get("download")
        if not download_rel:
            continue

        download_url = urljoin(base, download_rel)

        filename = _safe_filename(title)
        ext = os.path.splitext(filename)[1].lower()
        if not ext:
            # infer extension
            if media_type == "image/jpeg":
                filename += ".jpg"
            elif media_type == "image/webp":
                filename += ".webp"
            else:
                filename += ".png"

        local_path = os.path.join(CONFLUENCE_STORAGE_DIR, page_id, filename)

        try:
            confluence_download(download_url, local_path)
        except Exception as e:
            print(f"[WARN] Failed to download attachment {title}: {e}")
            continue

        ocr = ""
        caption = ""
        pdf_text = ""
        try:
            ocr = ocr_image(local_path).strip()
        except Exception as e:
            print(f"[WARN] OCR failed for {local_path}: {e}")

        try:
            caption = caption_image(local_path).strip()
        except Exception as e:
            print(f"[WARN] Captioning failed for {local_path}: {e}")

        if is_pdf:
            try:
                pdf_text = extract_pdf_text(local_path)
            except Exception as e:
                print(f"[WARN] PDF text extraction failed for {local_path}: {e}")

            combined = f"ATTACHMENT PDF: {title}\n\nPDF_TEXT:\n{pdf_text[:20000]}"

            results.append({
                "id": f"confluence_pdf_{page_id}_{filename}",
                "content": combined,
                "type": "pdf",
                "pageUrl": page_url,
                "fileUrl": f"/static/confluence/{page_id}/{filename}",
                "allowed_groups": ["all"]
            })
            continue

        combined = f"ATTACHMENT IMAGE: {title}\n\nCAPTION:\n{caption}\n\nOCR_TEXT:\n{ocr}"

        results.append({
            "id": f"confluence_img_{page_id}_{filename}",
            "content": combined,
            "type": "image",
            "pageUrl": page_url,
            "imageUrl": f"/static/confluence/{page_id}/{filename}",
            "allowed_groups": ["all"]
        })

    return results

def run():
    if not settings.confluence_base_url:
        raise RuntimeError("CONFLUENCE_BASE_URL missing")

    if not settings.confluence_email or not settings.confluence_api_token:
        raise RuntimeError("CONFLUENCE_EMAIL / CONFLUENCE_API_TOKEN missing")

    vector = get_vector_store()

    base = settings.confluence_base_url.rstrip("/")
    space = settings.confluence_space_key

    url = f"{base}/rest/api/content?spaceKey={space}&limit=50&expand=body.storage,version"
    resp = confluence_get(url).json()

    items = []

    for page in tqdm(resp.get("results", [])):
        page_id = page["id"]
        title = page["title"]
        body = page.get("body", {}).get("storage", {}).get("value", "")
        page_url = f"{base}/spaces/{space}/pages/{page_id}"

        content = f"TITLE: {title}\n\nBODY:\n{body}"

        items.append({
            "id": f"confluence_{page_id}",
            "content": content,
            "type": "text",
            "pageUrl": page_url,
            "allowed_groups": ["all"]
        })

        # Attachments (images)
        img_items = ingest_page_attachments(base, page_id, page_url)
        items.extend(img_items)

    if items:
        vector.upsert(items)

    print(f"Ingested {len(items)} documents (pages + image attachments).")

if __name__ == "__main__":
    run()
