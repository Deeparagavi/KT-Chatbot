from openai import OpenAI
from app.config import settings

_client = None

def _get_client():
    global _client
    if _client is None:
        _client = OpenAI(api_key=settings.openai_api_key)
    return _client

def answer_with_context(question: str, context_chunks: list[dict]) -> dict:
    client = _get_client()

    context_text = ""
    images = []
    citations = []

    for c in context_chunks:
        context_text += f"\n---\nSOURCE: {c.get('pageUrl','unknown')}\nCONTENT:\n{c.get('content','')[:2000]}\n"
        if c.get("imageUrl"):
            images.append(c["imageUrl"])
        citations.append(c.get("pageUrl", ""))

    system = (
        "You are an internal organization KT assistant. "
        "Answer using ONLY the provided context. "
        "If context is insufficient, say you don't know and suggest where to look. "
        "Always be structured and beginner-friendly."
    )

    resp = client.chat.completions.create(
        model=settings.openai_model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": f"QUESTION: {question}\n\nCONTEXT:{context_text}"}
        ],
        temperature=0.2
    )

    return {
        "answer": resp.choices[0].message.content,
        "citations": list(set([c for c in citations if c])),
        "images": list(set(images))
    }
